package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.text.TextWatcher;
import android.text.Editable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GoalWeightActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private RecyclerView recyclerViewGoal;
    private EditText editTextGoalDate;
    private EditText editTextGoalWeight;
    private Button buttonAdd;
    private Button buttonLogout;
    private Button buttonBack;
    private Button buttonSettings;
    private EntryAdapter entryAdapter;
    private ArrayList<Entry> entryList; // EntryAdapter expects ArrayList
    private long editingId = -1;
    private long userId = -1;

    private PreferencesManager prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        prefs = new PreferencesManager(this);

        // Apply theme/background depending on user's preference
        View root = findViewById(R.id.rootLayout);
        String theme = prefs.getTheme();
        if ("dark".equals(theme)) {
            root.setBackgroundResource(R.drawable.dark_background);
        } else {
            root.setBackgroundResource(R.drawable.gradient_bg);
        }

        db = new DatabaseHelper(this);

        recyclerViewGoal = findViewById(R.id.recyclerViewGoalEntries);
        editTextGoalDate = findViewById(R.id.editTextGoalDate);
        editTextGoalWeight = findViewById(R.id.editTextGoalWeight);

        // Buttons
        buttonAdd = findViewById(R.id.buttonAddGoalEntry);
        buttonLogout = findViewById(R.id.buttonLogout);
        buttonBack = findViewById(R.id.buttonBack);
        buttonSettings = findViewById(R.id.buttonSettings);

        recyclerViewGoal.setLayoutManager(new LinearLayoutManager(this));

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("userId")) {
            userId = intent.getLongExtra("userId", -1);
        }
        if (userId == -1) {
            userId = db.ensureDemoUser();
        }

        updateGoalWeightHint();

        entryList = db.getGoalEntriesForUser(userId);

        entryAdapter = new EntryAdapter(entryList, new EntryAdapter.OnEntryActionListener() {
            @Override
            public void onEdit(Entry entry, int position) {
                editingId = entry.getId();
                editTextGoalDate.setText(entry.getDate());
                String weightStr = entry.getWeight();
                if (weightStr != null && weightStr.endsWith(" lbs")) {
                    weightStr = weightStr.substring(0, weightStr.length() - 4);
                }
                if (weightStr != null && weightStr.endsWith(" kg")) {
                    weightStr = weightStr.substring(0, weightStr.length() - 3);
                }
                editTextGoalWeight.setText(weightStr);
            }

            @Override
            public void onDelete(Entry entry, int position) {
                // delete from DB then refresh
                db.deleteGoalEntry(entry.getId());
                refreshListFromDb();
            }
        });

        recyclerViewGoal.setAdapter(entryAdapter);

        // Settings button
        buttonSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        // Disable Add button until both goal date and weight are entered
        buttonAdd.setEnabled(false);
        TextWatcher goalFieldsWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String date = editTextGoalDate.getText().toString().trim();
                String weight = editTextGoalWeight.getText().toString().trim();
                buttonAdd.setEnabled(!date.isEmpty() && !weight.isEmpty());
            }
            @Override
            public void afterTextChanged(Editable s) { }
        };
        editTextGoalDate.addTextChangedListener(goalFieldsWatcher);
        editTextGoalWeight.addTextChangedListener(goalFieldsWatcher);

        buttonAdd.setOnClickListener(v -> {
            String date = editTextGoalDate.getText().toString().trim();
            String weightVal = editTextGoalWeight.getText().toString().trim();
            if (date.isEmpty() || weightVal.isEmpty()) {
                return;
            }

            if (editingId == -1) {
                long id = db.insertGoalEntry(userId, date, weightVal);
                if (id != -1) {
                    entryList.add(0, new Entry(id, date, weightVal + " lbs"));
                    entryAdapter.notifyItemInserted(0);
                }
            } else {
                db.updateGoalEntry(editingId, date, weightVal);
                for (int i = 0; i < entryList.size(); i++) {
                    if (entryList.get(i).getId() == editingId) {
                        entryList.set(i, new Entry(editingId, date, weightVal + " lbs"));
                        entryAdapter.notifyItemChanged(i);
                        break;
                    }
                }
                editingId = -1;
            }

            // clear inputs
            editTextGoalDate.setText("");
            editTextGoalWeight.setText("");
        });

        // Back button
        buttonBack.setOnClickListener(v -> {
            finish();
        });

        // Logout button
        buttonLogout.setOnClickListener(view -> {
            Intent out = new Intent(GoalWeightActivity.this, MainActivity.class);
            out.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(out);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        String theme = prefs.getTheme();
        View root = findViewById(R.id.rootLayout);
        if ("dark".equals(theme)) {
            root.setBackgroundResource(R.drawable.dark_background);
        } else {
            root.setBackgroundResource(R.drawable.gradient_bg);
        }
        updateGoalWeightHint();
        refreshListFromDb();
    }

    private void updateGoalWeightHint() {
        if (editTextGoalWeight == null) return;
        String unit = prefs.getUnit();
        if ("kg".equals(unit)) {
            editTextGoalWeight.setHint("Weight (kg)");
        } else {
            editTextGoalWeight.setHint("Weight (lbs)");
        }
    }

    private void refreshListFromDb() {
        entryList.clear();
        ArrayList<Entry> loaded = db.getGoalEntriesForUser(userId);
        if (loaded != null) entryList.addAll(loaded);
        entryAdapter.notifyDataSetChanged();
    }
}

