package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonCreateAccountConfirm;
    private Button buttonBackToLogin;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        db = new DatabaseHelper(this);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonCreateAccountConfirm = findViewById(R.id.buttonCreateAccountConfirm);
        buttonBackToLogin = findViewById(R.id.buttonBackToLogin);

        // Account confirm button
        buttonCreateAccountConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = editTextUsername.getText().toString().trim();
                String password = editTextPassword.getText().toString();
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                    return;
                }
                boolean created = db.registerUser(username, password);
                if (created) {
                    Toast.makeText(CreateAccountActivity.this, "Account created successfully!", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(CreateAccountActivity.this, SmsPermissionActivity.class);
                    intent.putExtra("username", username); // optional if you need it later
                    startActivity(intent);

                    finish(); // close CreateAccountActivity so user can't go back here
                } else {
                    Toast.makeText(CreateAccountActivity.this, "Username already exists or invalid input.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Back button
        buttonBackToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}

