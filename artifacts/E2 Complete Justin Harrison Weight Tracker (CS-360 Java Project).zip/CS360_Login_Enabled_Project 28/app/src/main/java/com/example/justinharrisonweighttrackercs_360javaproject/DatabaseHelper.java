package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "weight_tracker.db";
    private static final int DB_VERSION = 3;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD_HASH = "password_hash";

    // Weight entries table
    public static final String TABLE_WEIGHT = "weight_entries";
    public static final String COL_WEIGHT_ID = "id";
    public static final String COL_WEIGHT_USER_ID = "user_id";
    public static final String COL_WEIGHT_DATE = "date";
    public static final String COL_WEIGHT_VALUE = "value";
    public static final String COL_WEIGHT_NOTE = "note";

    // Goal weights table
    public static final String TABLE_GOAL = "goal_weights";
    public static final String COL_GOAL_ID = "id";
    public static final String COL_GOAL_USER_ID = "user_id";
    public static final String COL_GOAL_DATE = "date";
    public static final String COL_GOAL_VALUE = "value";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // SQL create statements
    private static final String SQL_CREATE_USERS =
            "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                    COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                    COL_PASSWORD_HASH + " TEXT NOT NULL)";

    private static final String SQL_CREATE_WEIGHT =
            "CREATE TABLE IF NOT EXISTS " + TABLE_WEIGHT + " (" +
                    COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_WEIGHT_USER_ID + " INTEGER NOT NULL, " +
                    COL_WEIGHT_DATE + " TEXT NOT NULL, " +
                    COL_WEIGHT_VALUE + " TEXT NOT NULL, " +
                    COL_WEIGHT_NOTE + " TEXT, " +
                    "FOREIGN KEY(" + COL_WEIGHT_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + "))";

    private static final String SQL_INDEX_WEIGHT =
            "CREATE INDEX IF NOT EXISTS idx_weight_user_date ON " + TABLE_WEIGHT + "(" + COL_WEIGHT_USER_ID + "," + COL_WEIGHT_DATE + ")";

    private static final String SQL_CREATE_GOAL =
            "CREATE TABLE IF NOT EXISTS " + TABLE_GOAL + " (" +
                    COL_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_GOAL_USER_ID + " INTEGER NOT NULL, " +
                    COL_GOAL_DATE + " TEXT NOT NULL, " +
                    COL_GOAL_VALUE + " TEXT NOT NULL, " +
                    "FOREIGN KEY(" + COL_GOAL_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + "))";

    private static final String SQL_INDEX_GOAL =
            "CREATE INDEX IF NOT EXISTS idx_goal_user_date ON " + TABLE_GOAL + "(" + COL_GOAL_USER_ID + "," + COL_GOAL_DATE + ")";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_USERS);
        db.execSQL(SQL_CREATE_WEIGHT);
        db.execSQL(SQL_INDEX_WEIGHT);
        db.execSQL(SQL_CREATE_GOAL);
        db.execSQL(SQL_INDEX_GOAL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_CREATE_USERS);
        db.execSQL(SQL_CREATE_WEIGHT);
        db.execSQL(SQL_INDEX_WEIGHT);
        db.execSQL(SQL_CREATE_GOAL);
        db.execSQL(SQL_INDEX_GOAL);
    }

    public long ensureDemoUser() {
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ?", new String[]{"demo"}, null, null, null);
        try {
            if (c != null && c.moveToFirst()) {
                return c.getLong(c.getColumnIndexOrThrow(COL_USER_ID));
            }
        } finally {
            if (c != null) c.close();
        }
        ContentValues v = new ContentValues();
        v.put(COL_USERNAME, "demo");
        v.put(COL_PASSWORD_HASH, "demo");
        long newId = db.insert(TABLE_USERS, null, v);
        return newId;
    }

    public boolean registerUser(String username, String password) {
        if (username == null || password == null) return false;
        if (getUserId(username) != -1) return false; // already exists
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_USERNAME, username);
        v.put(COL_PASSWORD_HASH, password);
        long id = db.insert(TABLE_USERS, null, v);
        return id != -1;
    }

    public boolean validateLogin(String username, String password) {
        if (username == null || password == null) return false;
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD_HASH + "=?",
                new String[]{username, password}, null, null, null);
        try {
            return c != null && c.moveToFirst();
        } finally {
            if (c != null) c.close();
        }
    }

    public long getUserId(String username) {
        if (username == null) return -1;
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + "=?", new String[]{username}, null, null, null);
        try {
            if (c != null && c.moveToFirst()) {
                return c.getLong(c.getColumnIndexOrThrow(COL_USER_ID));
            } else {
                return -1;
            }
        } finally {
            if (c != null) c.close();
        }
    }

    public long insertWeightEntry(long userId, String dateIso, String weight) {
        return insertWeightEntry(userId, dateIso, weight, "");
    }

    public long insertWeightEntry(long userId, String dateIso, String weight, String note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_WEIGHT_USER_ID, userId);
        cv.put(COL_WEIGHT_DATE, dateIso);
        cv.put(COL_WEIGHT_VALUE, weight);
        cv.put(COL_WEIGHT_NOTE, note);
        return db.insert(TABLE_WEIGHT, null, cv);
    }

    public int updateWeightEntry(long id, String dateIso, String weight) {
        return updateWeightEntry(id, dateIso, weight, "");
    }

    public int updateWeightEntry(long id, String dateIso, String weight, String note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_DATE, dateIso);
        values.put(COL_WEIGHT_VALUE, weight);
        values.put(COL_WEIGHT_NOTE, note);
        return db.update(TABLE_WEIGHT, values, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
    }

    public int deleteWeightEntry(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_WEIGHT, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
    }

    public ArrayList<Entry> getWeightEntriesForUser(long userId) {
        ArrayList<Entry> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_WEIGHT,
                new String[]{COL_WEIGHT_ID, COL_WEIGHT_DATE, COL_WEIGHT_VALUE},
                COL_WEIGHT_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null, COL_WEIGHT_DATE + " DESC");
        try {
            if (c != null && c.moveToFirst()) {
                int idIx = c.getColumnIndexOrThrow(COL_WEIGHT_ID);
                int dateIx = c.getColumnIndexOrThrow(COL_WEIGHT_DATE);
                int valueIx = c.getColumnIndexOrThrow(COL_WEIGHT_VALUE);
                do {
                    long id = c.getLong(idIx);
                    String date = c.getString(dateIx);
                    String weight = c.getString(valueIx) + " lbs";
                    list.add(new Entry(id, date, weight));
                } while (c.moveToNext());
            }
        } finally {
            if (c != null) c.close();
        }
        return list;
    }

    public long insertGoalEntry(long userId, String dateIso, String weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_GOAL_USER_ID, userId);
        cv.put(COL_GOAL_DATE, dateIso);
        cv.put(COL_GOAL_VALUE, weight);
        return db.insert(TABLE_GOAL, null, cv);
    }

    public int updateGoalEntry(long id, String dateIso, String weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_GOAL_DATE, dateIso);
        values.put(COL_GOAL_VALUE, weight);
        return db.update(TABLE_GOAL, values, COL_GOAL_ID + "=?", new String[]{String.valueOf(id)});
    }

    public int deleteGoalEntry(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_GOAL, COL_GOAL_ID + "=?", new String[]{String.valueOf(id)});
    }

    public ArrayList<Entry> getGoalEntriesForUser(long userId) {
        ArrayList<Entry> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_GOAL,
                new String[]{COL_GOAL_ID, COL_GOAL_DATE, COL_GOAL_VALUE},
                COL_GOAL_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null, COL_GOAL_DATE + " DESC");
        try {
            if (c != null && c.moveToFirst()) {
                int idIx = c.getColumnIndexOrThrow(COL_GOAL_ID);
                int dateIx = c.getColumnIndexOrThrow(COL_GOAL_DATE);
                int valueIx = c.getColumnIndexOrThrow(COL_GOAL_VALUE);
                do {
                    long id = c.getLong(idIx);
                    String date = c.getString(dateIx);
                    String weight = c.getString(valueIx) + " lbs";
                    list.add(new Entry(id, date, weight));
                } while (c.moveToNext());
            }
        } finally {
            if (c != null) c.close();
        }
        return list;
    }
}

