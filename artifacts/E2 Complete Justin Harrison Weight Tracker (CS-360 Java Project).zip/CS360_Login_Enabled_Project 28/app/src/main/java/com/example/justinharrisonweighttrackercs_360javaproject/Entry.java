package com.example.justinharrisonweighttrackercs_360javaproject;

public class Entry {
    private long id;
    private String date;
    private String weight;

    public Entry(long id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public long getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getWeight() {
        return weight;
    }

    public Entry(String date, String weight) {
        this.id = -1;
        this.date = date;
        this.weight = weight;
    }

}
