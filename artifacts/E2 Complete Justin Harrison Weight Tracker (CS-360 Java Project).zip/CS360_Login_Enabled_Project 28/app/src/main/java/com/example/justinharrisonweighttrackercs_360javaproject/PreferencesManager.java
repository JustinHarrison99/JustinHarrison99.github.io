package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesManager {
    private static final String PREFS_NAME = "user_settings";

    private static final String KEY_UNIT = "weight_unit"; // "lbs" or "kg"
    private static final String KEY_THEME = "theme";      // "normal" or "dark"


    private final SharedPreferences prefs;

    public PreferencesManager(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void setUnit(String unit) { prefs.edit().putString(KEY_UNIT, unit).apply(); }
    public String getUnit() { return prefs.getString(KEY_UNIT, "lbs"); }

    public void setTheme(String theme) { prefs.edit().putString(KEY_THEME, theme).apply(); }
    public String getTheme() { return prefs.getString(KEY_THEME, "normal"); }
}

