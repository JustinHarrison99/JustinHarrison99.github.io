package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.Intent;
import android.os.Bundle;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextWatcher;
import android.text.Editable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class WeightEntriesActivity extends AppCompatActivity {

    private RecyclerView recyclerViewEntries;
    private EntryAdapter entryAdapter;
    private ArrayList<Entry> entryList;
    private DatabaseHelper db;
    private long userId;
    private EditText editTextDate, editTextWeight;
    private Button buttonAddEntry, buttonGoalWeight, buttonLogout, buttonSettings;

    private TextView textDifference;

    private PreferencesManager prefs;
    private final DecimalFormat oneDecimalFormat = new DecimalFormat("0.0");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        prefs = new PreferencesManager(this);

        // Apply theme/background depending on user's preference
        View root = findViewById(R.id.rootLayout);
        String theme = prefs.getTheme();
        if ("dark".equals(theme)) {
            root.setBackgroundResource(R.drawable.dark_background);
        } else {
            root.setBackgroundResource(R.drawable.gradient_bg);
        }

        recyclerViewEntries = findViewById(R.id.recyclerViewEntries);
        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonAddEntry = findViewById(R.id.buttonAddEntry);
        buttonGoalWeight = findViewById(R.id.buttonGoalWeight);
        buttonLogout = findViewById(R.id.buttonLogout);
        buttonSettings = findViewById(R.id.buttonSettings);

        textDifference = findViewById(R.id.textDifference);

        updateWeightHint();

        entryList = new ArrayList<>();
        db = new DatabaseHelper(this);

        String username = getIntent().getStringExtra("username");
        if (username == null) username = "demo";
        userId = db.getUserId(username);
        if (userId == -1) {
            userId = db.ensureDemoUser();
        }

        entryList = db.getWeightEntriesForUser(userId);
        entryAdapter = new EntryAdapter(entryList, new EntryAdapter.OnEntryActionListener() {
            @Override
            public void onDelete(Entry entry, int position) {
                db.deleteWeightEntry(entry.getId());
                reload();
            }

            @Override
            public void onEdit(Entry entry, int position) {
                showEditDialog(entry);
            }
        });

        recyclerViewEntries.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewEntries.setAdapter(entryAdapter);
        reload();

        buttonSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        // Disable Add Entry button until both fields have text
        buttonAddEntry.setEnabled(false);
        TextWatcher addFieldsWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String dateText = editTextDate.getText().toString().trim();
                String weightText = editTextWeight.getText().toString().trim();
                buttonAddEntry.setEnabled(!dateText.isEmpty() && !weightText.isEmpty());
            }
            @Override public void afterTextChanged(Editable s) {}
        };
        editTextDate.addTextChangedListener(addFieldsWatcher);
        editTextWeight.addTextChangedListener(addFieldsWatcher);

        // Add Entry button
        buttonAddEntry.setOnClickListener(view -> {
            String date = editTextDate.getText().toString().trim();
            String rawWeight = editTextWeight.getText().toString().trim();

            String formattedWeight = validateAndFormatWeight(rawWeight);
            if (date.isEmpty() || formattedWeight == null) {
                showInvalidWeightDialog();
                return;
            }

            long id = db.insertWeightEntry(userId, date, formattedWeight);
            if (id != -1) {
                reload();
                editTextDate.setText("");
                editTextWeight.setText("");
            } else {
                Toast.makeText(this, "Failed to save entry", Toast.LENGTH_SHORT).show();
            }
        });

        // Goal Weight button
        buttonGoalWeight.setOnClickListener(view -> {
            Intent intent = new Intent(this, GoalWeightActivity.class);
            intent.putExtra("userId", userId);
            startActivity(intent);
        });

        // Logout button
        buttonLogout.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        View root = findViewById(R.id.rootLayout);
        String theme = prefs.getTheme();
        if ("dark".equals(theme)) {
            root.setBackgroundResource(R.drawable.dark_background);
        } else {
            root.setBackgroundResource(R.drawable.gradient_bg);
        }
        updateWeightHint();
        reload();
    }

    private void updateWeightHint() {
        if (editTextWeight == null) return;
        String unit = prefs.getUnit();
        if ("kg".equals(unit)) {
            editTextWeight.setHint("Weight (kg)");
        } else {
            editTextWeight.setHint("Weight (lbs)");
        }
    }

    private void reload() {
        ArrayList<Entry> data = db.getWeightEntriesForUser(userId);
        entryAdapter.updateData(data);

        updateDifferenceFromLastEntry(data);
    }

    private void showEditDialog(final Entry entry) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_weight, null, false);
        EditText inputDate = view.findViewById(R.id.inputDate);
        EditText inputWeight = view.findViewById(R.id.inputWeight);
        EditText inputNote = view.findViewById(R.id.inputNote);
        inputNote.setVisibility(View.GONE);

        inputDate.setText(entry.getDate());

        String wVal = entry.getWeight();
        if (wVal.endsWith(" lbs")) {
            wVal = wVal.substring(0, wVal.length() - 4);
        } else if (wVal.endsWith(" kg")) {
            wVal = wVal.substring(0, wVal.length() - 3);
        }
        inputWeight.setText(wVal);

        new AlertDialog.Builder(this)
                .setTitle("Edit Entry")
                .setView(view)
                .setPositiveButton("Update", (d, which) -> {
                    String date = inputDate.getText().toString().trim();
                    String rawWeight = inputWeight.getText().toString().trim();

                    String formattedWeight = validateAndFormatWeight(rawWeight);
                    if (date.isEmpty() || formattedWeight == null) {
                        showInvalidWeightDialog();
                        return;
                    }

                    db.updateWeightEntry(entry.getId(), date, formattedWeight);
                    reload();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String validateAndFormatWeight(String input) {
        if (input == null || input.trim().isEmpty()) return null;
        if (input.contains("-")) return null;

        double value;
        try {
            value = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            return null;
        }

        if (value < 0 || value >= 1000) return null;

        return oneDecimalFormat.format(value);
    }

    private void showInvalidWeightDialog() {
        new AlertDialog.Builder(this)
                .setMessage("Try again. Please input a valid weight.")
                .setPositiveButton("Okay", (d, w) -> d.dismiss())
                .setCancelable(false)
                .show();
    }

    // Difference calculation
    private void updateDifferenceFromLastEntry(ArrayList<Entry> data) {
        if (textDifference == null || data == null || data.size() < 2) {
            if (textDifference != null) {
                textDifference.setVisibility(View.GONE);
            }
            return;
        }

        try {
            Entry latest = data.get(0);
            Entry previous = data.get(1);

            String[] latestParts = latest.getWeight().split(" ");
            String[] previousParts = previous.getWeight().split(" ");

            double latestValue = Double.parseDouble(latestParts[0]);
            double previousValue = Double.parseDouble(previousParts[0]);
            String unit = latestParts[1];

            double diff = latestValue - previousValue;
            String sign = diff > 0 ? "+" : "";

            textDifference.setText(
                    "Difference From Last Entry: " +
                            sign +
                            oneDecimalFormat.format(Math.abs(diff)) +
                            " " +
                            unit
            );
            textDifference.setVisibility(View.VISIBLE);

        } catch (Exception e) {
            textDifference.setVisibility(View.GONE);
        }
    }
}

