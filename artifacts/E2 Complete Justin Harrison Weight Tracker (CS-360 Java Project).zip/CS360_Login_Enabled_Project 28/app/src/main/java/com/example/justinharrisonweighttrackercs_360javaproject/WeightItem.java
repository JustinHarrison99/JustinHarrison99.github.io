package com.example.justinharrisonweighttrackercs_360javaproject;

public class WeightItem {
    public long id;
    public String date;   // String for the date
    public String weight; // String for the weight
    public String note;

    public WeightItem(long id, String date, String weight, String note) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.note = note;
    }
}
