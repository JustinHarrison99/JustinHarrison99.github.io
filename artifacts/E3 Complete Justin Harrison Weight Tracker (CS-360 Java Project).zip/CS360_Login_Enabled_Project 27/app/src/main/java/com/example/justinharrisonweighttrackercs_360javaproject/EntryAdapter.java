package com.example.justinharrisonweighttrackercs_360javaproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.app.AlertDialog;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Locale;

public class EntryAdapter extends RecyclerView.Adapter<EntryAdapter.EntryViewHolder> {

    public interface OnEntryActionListener {
        void onDelete(Entry entry, int position);
        void onEdit(Entry entry, int position);
    }

    private ArrayList<Entry> entryList;
    private OnEntryActionListener listener;

    public EntryAdapter(ArrayList<Entry> entryList, OnEntryActionListener listener) {
        this.entryList = entryList;
        this.listener = listener;
    }

    public void updateData(ArrayList<Entry> newData) {
        this.entryList = newData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public EntryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.entry_row, parent, false);
        return new EntryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EntryViewHolder holder, int position) {
        Entry entry = entryList.get(position);
        holder.textDate.setText(entry.getDate());

        // Determine unit of measurement
        PreferencesManager prefs = new PreferencesManager(holder.itemView.getContext());
        String unit = prefs.getUnit(); // "lbs" or "kg"

        String raw = entry.getWeight();
        if (raw == null) raw = "";
        raw = raw.replace(" lbs", "").replace(" kg", "").trim();

        double value = 0.0;
        try {
            value = Double.parseDouble(raw);
        } catch (NumberFormatException ex) {
            holder.textWeight.setText(entry.getWeight());
        }

        if (!Double.isNaN(value) && value != 0.0) {
            if (unit.equals("kg")) {
                double kg = value * 0.45359237;
                holder.textWeight.setText(String.format(Locale.US, "%.1f kg", kg));
            } else {
                // show lbs with one decimal if not an integer
                if (Math.abs(value - Math.round(value)) < 0.001) {
                    holder.textWeight.setText(String.format(Locale.US, "%d lbs", (int)Math.round(value)));
                } else {
                    holder.textWeight.setText(String.format(Locale.US, "%.1f lbs", value));
                }
            }
        } else {
            holder.textWeight.setText(entry.getWeight());
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    int pos = holder.getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        listener.onEdit(entry, pos);
                    }
                }
            }
        });

        holder.iconDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Confirmation before deleting
                AlertDialog.Builder builder = new AlertDialog.Builder(holder.itemView.getContext());
                builder.setTitle("Confirm Delete")
                        .setMessage("Are you sure you want to delete this entry?")
                        .setPositiveButton("Delete", (dialog, which) -> {
                            if (listener != null) {
                                int pos = holder.getAdapterPosition();
                                if (pos != RecyclerView.NO_POSITION) {
                                    listener.onDelete(entry, pos);
                                    // show success message after deletion
                                    Toast.makeText(holder.itemView.getContext(), "Entry Successfully Deleted", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return entryList == null ? 0 : entryList.size();
    }

    static class EntryViewHolder extends RecyclerView.ViewHolder {
        TextView textDate, textWeight;
        ImageView iconDelete;

        EntryViewHolder(@NonNull View itemView) {
            super(itemView);
            textDate = itemView.findViewById(R.id.textDate);
            textWeight = itemView.findViewById(R.id.textWeight);
            iconDelete = itemView.findViewById(R.id.iconDelete);
        }
    }
}


