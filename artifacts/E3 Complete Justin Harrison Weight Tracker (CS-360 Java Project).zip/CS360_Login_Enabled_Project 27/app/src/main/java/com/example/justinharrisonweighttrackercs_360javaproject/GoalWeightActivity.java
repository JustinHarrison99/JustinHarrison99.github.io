package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.app.AlertDialog;
import android.text.TextWatcher;
import android.text.Editable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public class GoalWeightActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private RecyclerView recyclerViewGoal;
    private EditText editTextGoalDate;
    private EditText editTextGoalWeight;
    private Button buttonAdd;
    private Button buttonLogout;
    private Button buttonBack;
    private Button buttonSettings;
    private EntryAdapter entryAdapter;
    private ArrayList<Entry> entryList;
    private long editingId = -1;
    private long userId = -1;

    private PreferencesManager prefs;

    private TextView textGoalProjection;

    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat("MM/dd/yy", Locale.US);

    // Search
    private EditText editTextSearchGoal;
    private String currentSearchQuery = "";

    // Additions
    private Spinner spinnerGoalSort;
    private Button buttonGoalReset;
    private TextView textGoalEntryCount;
    private String currentSortMode = "Most Recent";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        prefs = new PreferencesManager(this);

        View root = findViewById(R.id.rootLayout);
        String theme = prefs.getTheme();
        if ("dark".equals(theme)) {
            root.setBackgroundResource(R.drawable.dark_background);
        } else {
            root.setBackgroundResource(R.drawable.gradient_bg);
        }

        db = new DatabaseHelper(this);

        recyclerViewGoal = findViewById(R.id.recyclerViewGoalEntries);
        editTextGoalDate = findViewById(R.id.editTextGoalDate);
        editTextGoalWeight = findViewById(R.id.editTextGoalWeight);

        buttonAdd = findViewById(R.id.buttonAddGoalEntry);
        buttonLogout = findViewById(R.id.buttonLogout);
        buttonBack = findViewById(R.id.buttonBack);
        buttonSettings = findViewById(R.id.buttonSettings);

        textGoalProjection = findViewById(R.id.textGoalProjection);

        editTextSearchGoal = findViewById(R.id.editTextSearchGoal);
        spinnerGoalSort = findViewById(R.id.spinnerGoalSort);
        buttonGoalReset = findViewById(R.id.buttonResetGoalEntries);
        textGoalEntryCount = findViewById(R.id.textGoalEntriesCount);

        recyclerViewGoal.setLayoutManager(new LinearLayoutManager(this));

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("userId")) {
            userId = intent.getLongExtra("userId", -1);
        }
        if (userId == -1) {
            userId = db.ensureDemoUser();
        }

        updateGoalWeightHint();

        entryList = db.getGoalEntriesForUser(userId);

        entryAdapter = new EntryAdapter(entryList, new EntryAdapter.OnEntryActionListener() {
            @Override
            public void onEdit(Entry entry, int position) {
                editingId = entry.getId();
                editTextGoalDate.setText(entry.getDate());
                String w = entry.getWeight();
                if (w.endsWith(" lbs")) w = w.substring(0, w.length() - 4);
                if (w.endsWith(" kg")) w = w.substring(0, w.length() - 3);
                editTextGoalWeight.setText(w);
            }

            @Override
            public void onDelete(Entry entry, int position) {
                db.deleteGoalEntry(entry.getId());
                refreshListFromDb();
            }
        });

        recyclerViewGoal.setAdapter(entryAdapter);

        buttonSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        // Sorter (Sort By...)
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(
                this,
                R.layout.spinner_item_white,
                new String[]{"Most Recent", "Lowest to Highest", "Highest to Lowest"}
        );
        sortAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item_white);
        spinnerGoalSort.setAdapter(sortAdapter);

        spinnerGoalSort.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                currentSortMode = parent.getItemAtPosition(position).toString();
                refreshListFromDb();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        buttonAdd.setEnabled(false);
        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                buttonAdd.setEnabled(
                        !editTextGoalDate.getText().toString().trim().isEmpty() &&
                                !editTextGoalWeight.getText().toString().trim().isEmpty()
                );
            }
            @Override public void afterTextChanged(Editable s) {}
        };
        editTextGoalDate.addTextChangedListener(watcher);
        editTextGoalWeight.addTextChangedListener(watcher);

        buttonAdd.setOnClickListener(v -> {
            String date = editTextGoalDate.getText().toString().trim();
            String weight = editTextGoalWeight.getText().toString().trim();
            if (date.isEmpty() || weight.isEmpty()) return;

            if (editingId == -1) {
                long id = db.insertGoalEntry(userId, date, weight);
                if (id != -1) entryList.add(0, new Entry(id, date, weight + " lbs"));
            } else {
                db.updateGoalEntry(editingId, date, weight);
                for (int i = 0; i < entryList.size(); i++) {
                    if (entryList.get(i).getId() == editingId) {
                        entryList.set(i, new Entry(editingId, date, weight + " lbs"));
                        break;
                    }
                }
                editingId = -1;
            }

            entryAdapter.notifyDataSetChanged();
            editTextGoalDate.setText("");
            editTextGoalWeight.setText("");
            updateGoalProjection();
            updateEntryCount();
        });

        buttonBack.setOnClickListener(v -> finish());

        buttonLogout.setOnClickListener(v -> {
            Intent out = new Intent(this, MainActivity.class);
            out.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(out);
            finish();
        });

        // Search
        editTextSearchGoal.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    actionId == EditorInfo.IME_ACTION_DONE) {

                currentSearchQuery = editTextSearchGoal.getText().toString().trim();
                refreshListFromDb();
                return true;
            }
            return false;
        });

        // Reset Button (Delete ALL entries)
        buttonGoalReset.setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle("Reset Goal Entries")
                        .setMessage("This will permanently delete ALL goal entries. Continue?")
                        .setPositiveButton("Yes", (d, w) -> {
                            db.deleteAllGoalEntriesForUser(userId);
                            currentSearchQuery = "";
                            editTextSearchGoal.setText("");
                            refreshListFromDb();
                        })
                        .setNegativeButton("Cancel", null)
                        .show()
        );

        updateGoalProjection();
        updateEntryCount();
    }

    @Override
    protected void onResume() {
        super.onResume();
        View root = findViewById(R.id.rootLayout);
        root.setBackgroundResource(
                "dark".equals(prefs.getTheme())
                        ? R.drawable.dark_background
                        : R.drawable.gradient_bg
        );
        updateGoalWeightHint();
        refreshListFromDb();
        updateGoalProjection();
    }

    private void updateGoalWeightHint() {
        if (editTextGoalWeight == null) return;
        editTextGoalWeight.setHint(
                "kg".equals(prefs.getUnit()) ? "Weight (kg)" : "Weight (lbs)"
        );
    }

    private void refreshListFromDb() {
        entryList.clear();
        ArrayList<Entry> data = db.getGoalEntriesForUser(userId);

        if (currentSearchQuery != null && !currentSearchQuery.isEmpty()) {
            for (Entry e : data) {
                if (e.getDate().contains(currentSearchQuery) ||
                        e.getWeight().contains(currentSearchQuery)) {
                    entryList.add(e);
                }
            }
        } else {
            entryList.addAll(data);
        }

        if ("Lowest to Highest".equals(currentSortMode)) {
            Collections.sort(entryList, Comparator.comparingDouble(
                    e -> Double.parseDouble(e.getWeight().split(" ")[0])
            ));
        } else if ("Highest to Lowest".equals(currentSortMode)) {
            Collections.sort(entryList, (a, b) ->
                    Double.compare(
                            Double.parseDouble(b.getWeight().split(" ")[0]),
                            Double.parseDouble(a.getWeight().split(" ")[0])
                    ));
        }

        entryAdapter.notifyDataSetChanged();
        updateEntryCount();
    }

    private void updateEntryCount() {
        if (textGoalEntryCount != null) {
            textGoalEntryCount.setText("Entries: " + entryList.size());
        }
    }

    private void updateGoalProjection() {
        ArrayList<Entry> weights = db.getWeightEntriesForUser(userId);

        if (weights == null || weights.size() < 3) {
            textGoalProjection.setText("Goal Projection: Not Enough Data");
            return;
        }

        try {
            Entry e1 = weights.get(0);
            Entry e3 = weights.get(2);

            double w1 = Double.parseDouble(e1.getWeight().split(" ")[0]);
            double w3 = Double.parseDouble(e3.getWeight().split(" ")[0]);

            Date d1 = dateFormat.parse(e1.getDate());
            Date d3 = dateFormat.parse(e3.getDate());

            long days =
                    Math.abs(d1.getTime() - d3.getTime()) / (1000 * 60 * 60 * 24);

            if (days == 0) {
                textGoalProjection.setText("Goal Projection: Cannot Predict Based on Current Trend");
                return;
            }

            double avgDailyChange = (w1 - w3) / days;

            Entry latestGoal = entryList.isEmpty() ? null : entryList.get(0);
            if (latestGoal == null) {
                textGoalProjection.setText("Goal Projection: Not Enough Data");
                return;
            }

            double goalWeight =
                    Double.parseDouble(latestGoal.getWeight().split(" ")[0]);

            double daysToGoal = (goalWeight - w1) / avgDailyChange;

            if (avgDailyChange == 0 || daysToGoal <= 0 || Double.isInfinite(daysToGoal)) {
                textGoalProjection.setText("Goal Projection: Cannot Predict Based on Current Trend");
                return;
            }

            textGoalProjection.setText(
                    "Goal Projection: " + (int) Math.ceil(daysToGoal) +
                            " Days Left (Assuming Daily Use)"
            );

        } catch (Exception e) {
            textGoalProjection.setText("Goal Projection: Cannot Predict Based on Current Trend");
        }
    }
}

