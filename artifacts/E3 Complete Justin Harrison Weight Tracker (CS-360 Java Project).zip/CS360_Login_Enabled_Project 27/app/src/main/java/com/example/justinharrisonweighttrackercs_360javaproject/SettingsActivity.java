package com.example.justinharrisonweighttrackercs_360javaproject;

import android.os.Bundle;
import android.widget.Switch;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private PreferencesManager prefs;
    private Button buttonBackSettings;
    private Switch switchUnits;
    private Switch switchDarkMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = new PreferencesManager(this);

        switchUnits = findViewById(R.id.switchUnits);
        switchDarkMode = findViewById(R.id.switchDarkMode);
        buttonBackSettings = findViewById(R.id.buttonBackSettings);

        // Initialize switches based on saved prefs
        switchUnits.setChecked(prefs.getUnit().equals("kg"));
        switchDarkMode.setChecked(prefs.getTheme().equals("dark"));

        // Unit of measurement toggle (either lbs default or kg)
        switchUnits.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.setUnit(isChecked ? "kg" : "lbs");
        });

        // Dark mode
        switchDarkMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.setTheme(isChecked ? "dark" : "normal");
        });

        // Back button
        buttonBackSettings.setOnClickListener(v -> {
            finish(); // return to previous screen
        });
    }
}
