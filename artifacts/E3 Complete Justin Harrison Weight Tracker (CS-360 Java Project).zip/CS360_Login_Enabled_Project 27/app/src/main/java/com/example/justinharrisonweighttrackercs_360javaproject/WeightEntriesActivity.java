package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.Intent;
import android.os.Bundle;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class WeightEntriesActivity extends AppCompatActivity {

    private RecyclerView recyclerViewEntries;
    private EntryAdapter entryAdapter;
    private ArrayList<Entry> entryList;
    private DatabaseHelper db;
    private long userId;
    private EditText editTextDate, editTextWeight;
    private Button buttonAddEntry, buttonGoalWeight, buttonLogout, buttonSettings;

    private TextView textDifference;

    // New Additions (entry count/sorter/reset)
    private TextView textEntryCount;
    private Spinner spinnerSort;
    private Button buttonReset;
    private String currentSortMode = "Most Recent";

    // Search
    private EditText editTextSearch;
    private String currentSearchQuery = "";

    private PreferencesManager prefs;
    private final DecimalFormat oneDecimalFormat = new DecimalFormat("0.0");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        prefs = new PreferencesManager(this);

        View root = findViewById(R.id.rootLayout);
        String theme = prefs.getTheme();
        if ("dark".equals(theme)) {
            root.setBackgroundResource(R.drawable.dark_background);
        } else {
            root.setBackgroundResource(R.drawable.gradient_bg);
        }

        recyclerViewEntries = findViewById(R.id.recyclerViewEntries);
        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonAddEntry = findViewById(R.id.buttonAddEntry);
        buttonGoalWeight = findViewById(R.id.buttonGoalWeight);
        buttonLogout = findViewById(R.id.buttonLogout);
        buttonSettings = findViewById(R.id.buttonSettings);

        textDifference = findViewById(R.id.textDifference);

        textEntryCount = findViewById(R.id.textEntryCount);
        spinnerSort = findViewById(R.id.spinnerSort);
        buttonReset = findViewById(R.id.buttonReset);

        // Search
        editTextSearch = findViewById(R.id.editTextSearch);

        updateWeightHint();

        entryList = new ArrayList<>();
        db = new DatabaseHelper(this);

        String username = getIntent().getStringExtra("username");
        if (username == null) username = "demo";
        userId = db.getUserId(username);
        if (userId == -1) {
            userId = db.ensureDemoUser();
        }

        entryList = db.getWeightEntriesForUser(userId);
        entryAdapter = new EntryAdapter(entryList, new EntryAdapter.OnEntryActionListener() {
            @Override
            public void onDelete(Entry entry, int position) {
                db.deleteWeightEntry(entry.getId());
                reload();
            }

            @Override
            public void onEdit(Entry entry, int position) {
                showEditDialog(entry);
            }
        });

        recyclerViewEntries.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewEntries.setAdapter(entryAdapter);
        reload();

        buttonSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        buttonAddEntry.setEnabled(false);
        TextWatcher addFieldsWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String dateText = editTextDate.getText().toString().trim();
                String weightText = editTextWeight.getText().toString().trim();
                buttonAddEntry.setEnabled(!dateText.isEmpty() && !weightText.isEmpty());
            }
            @Override public void afterTextChanged(Editable s) {}
        };
        editTextDate.addTextChangedListener(addFieldsWatcher);
        editTextWeight.addTextChangedListener(addFieldsWatcher);

        buttonAddEntry.setOnClickListener(view -> {
            String date = editTextDate.getText().toString().trim();
            String rawWeight = editTextWeight.getText().toString().trim();

            String formattedWeight = validateAndFormatWeight(rawWeight);
            if (date.isEmpty() || formattedWeight == null) {
                showInvalidWeightDialog();
                return;
            }

            long id = db.insertWeightEntry(userId, date, formattedWeight);
            if (id != -1) {
                reload();
                editTextDate.setText("");
                editTextWeight.setText("");
            } else {
                Toast.makeText(this, "Failed to save entry", Toast.LENGTH_SHORT).show();
            }
        });

        buttonGoalWeight.setOnClickListener(view -> {
            Intent intent = new Intent(this, GoalWeightActivity.class);
            intent.putExtra("userId", userId);
            startActivity(intent);
        });

        buttonLogout.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(
                this,
                R.layout.spinner_item_white,
                new String[]{"Most Recent", "Lowest to Highest", "Highest to Lowest"}
        );
        sortAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item_white);
        spinnerSort.setAdapter(sortAdapter);

        spinnerSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentSortMode = parent.getItemAtPosition(position).toString();
                reload();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        buttonReset.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setMessage("Are you sure you want to reset data? This will permanently delete all of your weight entries.")
                    .setPositiveButton("Confirm", (d, w) -> {
                        db.deleteAllWeightEntriesForUser(userId);
                        reload();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Search Action
        editTextSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    actionId == EditorInfo.IME_ACTION_DONE) {

                currentSearchQuery = editTextSearch.getText().toString().trim();
                reload();
                return true;
            }
            return false;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        View root = findViewById(R.id.rootLayout);
        String theme = prefs.getTheme();
        if ("dark".equals(theme)) {
            root.setBackgroundResource(R.drawable.dark_background);
        } else {
            root.setBackgroundResource(R.drawable.gradient_bg);
        }
        updateWeightHint();
        reload();
    }

    private void updateWeightHint() {
        if (editTextWeight == null) return;
        String unit = prefs.getUnit();
        if ("kg".equals(unit)) {
            editTextWeight.setHint("Weight (kg)");
        } else {
            editTextWeight.setHint("Weight (lbs)");
        }
    }

    private void reload() {
        ArrayList<Entry> data = db.getWeightEntriesForUser(userId);

        // Search Filter
        if (currentSearchQuery != null && !currentSearchQuery.isEmpty()) {
            ArrayList<Entry> filtered = new ArrayList<>();
            for (Entry e : data) {
                if (e.getDate().contains(currentSearchQuery) ||
                        e.getWeight().contains(currentSearchQuery)) {
                    filtered.add(e);
                }
            }
            data = filtered;
        }

        if ("Lowest to Highest".equals(currentSortMode)) {
            Collections.sort(data, Comparator.comparingDouble(e -> parseWeight(e.getWeight())));
        } else if ("Highest to Lowest".equals(currentSortMode)) {
            Collections.sort(data, (a, b) ->
                    Double.compare(parseWeight(b.getWeight()), parseWeight(a.getWeight())));
        }

        entryAdapter.updateData(data);

        if (textEntryCount != null) {
            textEntryCount.setText("Entries: " + data.size());
        }

        updateDifferenceFromLastEntry(data);
    }

    private double parseWeight(String weight) {
        try {
            return Double.parseDouble(weight.split(" ")[0]);
        } catch (Exception e) {
            return 0;
        }
    }

    private void showEditDialog(final Entry entry) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_weight, null, false);
        EditText inputDate = view.findViewById(R.id.inputDate);
        EditText inputWeight = view.findViewById(R.id.inputWeight);
        EditText inputNote = view.findViewById(R.id.inputNote);
        inputNote.setVisibility(View.GONE);

        inputDate.setText(entry.getDate());

        String wVal = entry.getWeight();
        if (wVal.endsWith(" lbs")) {
            wVal = wVal.substring(0, wVal.length() - 4);
        } else if (wVal.endsWith(" kg")) {
            wVal = wVal.substring(0, wVal.length() - 3);
        }
        inputWeight.setText(wVal);

        new AlertDialog.Builder(this)
                .setTitle("Edit Entry")
                .setView(view)
                .setPositiveButton("Update", (d, which) -> {
                    String date = inputDate.getText().toString().trim();
                    String rawWeight = inputWeight.getText().toString().trim();

                    String formattedWeight = validateAndFormatWeight(rawWeight);
                    if (date.isEmpty() || formattedWeight == null) {
                        showInvalidWeightDialog();
                        return;
                    }

                    db.updateWeightEntry(entry.getId(), date, formattedWeight);
                    reload();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String validateAndFormatWeight(String input) {
        if (input == null || input.trim().isEmpty()) return null;
        if (input.contains("-")) return null;

        double value;
        try {
            value = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            return null;
        }

        if (value < 0 || value >= 1000) return null;

        return oneDecimalFormat.format(value);
    }

    private void showInvalidWeightDialog() {
        new AlertDialog.Builder(this)
                .setMessage("Try again. Please input a valid weight.")
                .setPositiveButton("Okay", (d, w) -> d.dismiss())
                .setCancelable(false)
                .show();
    }

    private void updateDifferenceFromLastEntry(ArrayList<Entry> data) {
        if (textDifference == null || data == null || data.size() < 2) {
            if (textDifference != null) {
                textDifference.setVisibility(View.GONE);
            }
            return;
        }

        try {
            Entry latest = data.get(0);
            Entry previous = data.get(1);

            String[] latestParts = latest.getWeight().split(" ");
            String[] previousParts = previous.getWeight().split(" ");

            double latestValue = Double.parseDouble(latestParts[0]);
            double previousValue = Double.parseDouble(previousParts[0]);
            String unit = latestParts[1];

            double diff = latestValue - previousValue;
            String sign = diff > 0 ? "+" : "";

            textDifference.setText(
                    "Difference From Last Entry: " +
                            sign +
                            oneDecimalFormat.format(Math.abs(diff)) +
                            " " +
                            unit
            );
            textDifference.setVisibility(View.VISIBLE);

        } catch (Exception e) {
            textDifference.setVisibility(View.GONE);
        }
    }
}

