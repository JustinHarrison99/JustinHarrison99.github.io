package com.example.justinharrisonweighttrackercs_360javaproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class WeightGridAdapter extends RecyclerView.Adapter<WeightGridAdapter.VH> {

    public interface Listener {
        void onEdit(WeightItem item);
        void onDelete(WeightItem item);
    }

    private final Listener listener;
    private final List<WeightItem> items = new ArrayList<>();

    public WeightGridAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submitList(List<WeightItem> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight_card, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        WeightItem item = items.get(position);
        h.date.setText(item.date);
        h.weight.setText(item.weight);
        h.note.setText(item.note == null ? "" : item.note);
        h.btnEdit.setOnClickListener(v -> listener.onEdit(item));
        h.btnDelete.setOnClickListener(v -> listener.onDelete(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView date, weight, note;
        ImageButton btnEdit, btnDelete;
        VH(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.textDate);
            weight = itemView.findViewById(R.id.textWeight);
            note = itemView.findViewById(R.id.textNote);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
