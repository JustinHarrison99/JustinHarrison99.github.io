package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.UUID;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "weight_tracker.db";
    private static final int DB_VERSION = 2;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD_HASH = "password_hash";
    public static final String COL_SALT = "salt";

    // Weight entries table
    public static final String TABLE_WEIGHT = "weight_entries";
    public static final String COL_WEIGHT_ID = "id";
    public static final String COL_WEIGHT_USER_ID = "user_id";
    public static final String COL_WEIGHT_DATE = "entry_date";
    public static final String COL_WEIGHT_VALUE = "weight";

    // Create SQL
    private static final String SQL_CREATE_USERS =
            "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                    COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                    COL_PASSWORD_HASH + " TEXT NOT NULL, " +
                    COL_SALT + " TEXT NOT NULL" +
                    ");";

    private static final String SQL_CREATE_WEIGHT =
            "CREATE TABLE IF NOT EXISTS " + TABLE_WEIGHT + " (" +
                    COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_WEIGHT_USER_ID + " INTEGER NOT NULL, " +
                    COL_WEIGHT_DATE + " TEXT NOT NULL, " +
                    COL_WEIGHT_VALUE + " TEXT NOT NULL, " +
                    "FOREIGN KEY(" + COL_WEIGHT_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + ")" +
                    ");";

    private static final String SQL_INDEX_WEIGHT =
            "CREATE INDEX IF NOT EXISTS idx_weight_user_date ON " +
                    TABLE_WEIGHT + " (" + COL_WEIGHT_USER_ID + ", " + COL_WEIGHT_DATE + ")";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_USERS);
        db.execSQL(SQL_CREATE_WEIGHT);
        db.execSQL(SQL_INDEX_WEIGHT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Non-destructive upgrade: ensure new tables and indexes exist
        db.execSQL(SQL_CREATE_USERS);
        db.execSQL(SQL_CREATE_WEIGHT);
        db.execSQL(SQL_INDEX_WEIGHT);
    }

    /** Returns true if a new user was created; false if username already exists. */
    public boolean registerUser(String username, String rawPassword) {
        if (username == null || username.trim().isEmpty() || rawPassword == null || rawPassword.isEmpty()) {
            return false;
        }
        username = username.trim();
        if (userExists(username)) {
            return false;
        }
        String salt = UUID.randomUUID().toString();
        String hash = PasswordUtils.hashPassword(rawPassword, salt);
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD_HASH, hash);
        cv.put(COL_SALT, salt);
        SQLiteDatabase db = getWritableDatabase();
        long id = db.insert(TABLE_USERS, null, cv);
        return id != -1;
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, new String[]{COL_USER_ID}, COL_USERNAME + " = ?", new String[]{username}, null, null, null);
        boolean exists = (c != null && c.moveToFirst());
        if (c != null) c.close();
        return exists;
    }

    /** Returns true if username/password pair is valid. */
    public boolean validateLogin(String username, String rawPassword) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, new String[]{COL_PASSWORD_HASH, COL_SALT}, COL_USERNAME + " = ?", new String[]{username}, null, null, null);
        if (c != null && c.moveToFirst()) {
            String storedHash = c.getString(0);
            String salt = c.getString(1);
            c.close();
            String candidate = PasswordUtils.hashPassword(rawPassword, salt);
            return storedHash.equals(candidate);
        }
        if (c != null) c.close();
        return false;
    }

    // Utility: get user id by username
    public long getUserId(String username) {
        SQLiteDatabase dbx = getReadableDatabase();
        Cursor c = dbx.query(TABLE_USERS, new String[]{COL_USER_ID}, COL_USERNAME + "=?", new String[]{username}, null, null, null);
        try {
            if (c.moveToFirst()) {
                return c.getLong(0);
            }
            return -1;
        } finally {
            c.close();
        }
    }

    public long insertWeightEntry(long userId, String dateIso, String weight) {
        SQLiteDatabase dbx = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_WEIGHT_USER_ID, userId);
        v.put(COL_WEIGHT_DATE, dateIso);
        v.put(COL_WEIGHT_VALUE, weight);
        return dbx.insert(TABLE_WEIGHT, null, v);
    }

    public int updateWeightEntry(long entryId, String dateIso, String weight) {
        SQLiteDatabase dbx = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_WEIGHT_DATE, dateIso);
        v.put(COL_WEIGHT_VALUE, weight);
        return dbx.update(TABLE_WEIGHT, v, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(entryId)});
    }

    public int deleteWeightEntry(long entryId) {
        SQLiteDatabase dbx = getWritableDatabase();
        return dbx.delete(TABLE_WEIGHT, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(entryId)});
    }

    public java.util.ArrayList<Entry> getWeightEntriesForUser(long userId) {
        java.util.ArrayList<Entry> list = new java.util.ArrayList<>();
        SQLiteDatabase dbx = getReadableDatabase();
        Cursor c = dbx.query(TABLE_WEIGHT, null, COL_WEIGHT_USER_ID + "=?", new String[]{String.valueOf(userId)}, null, null, COL_WEIGHT_DATE + " DESC");
        try {
            int idIx = c.getColumnIndexOrThrow(COL_WEIGHT_ID);
            int dateIx = c.getColumnIndexOrThrow(COL_WEIGHT_DATE);
            int weightIx = c.getColumnIndexOrThrow(COL_WEIGHT_VALUE);
            while (c.moveToNext()) {
                long id = c.getLong(idIx);
                String date = c.getString(dateIx);
                String weight = c.getString(weightIx) + " lbs";
                list.add(new Entry(id, date, weight));
            }
        } finally {
            c.close();
        }
        return list;
    }
}
