package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GoalWeightActivity extends AppCompatActivity {

    private RecyclerView recyclerViewGoalEntries;
    private EntryAdapter entryAdapter;
    private ArrayList<Entry> entryList;
    private EditText editTextGoalDate, editTextGoalWeight;
    private Button buttonAddGoalEntry, buttonBack, buttonLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        recyclerViewGoalEntries = findViewById(R.id.recyclerViewGoalEntries);
        editTextGoalDate = findViewById(R.id.editTextGoalDate);
        editTextGoalWeight = findViewById(R.id.editTextGoalWeight);
        buttonAddGoalEntry = findViewById(R.id.buttonAddGoalEntry);
        buttonBack = findViewById(R.id.buttonBack);
        buttonLogout = findViewById(R.id.buttonLogout); // logout button

        entryList = new ArrayList<>();
        entryAdapter = new EntryAdapter(entryList, new EntryAdapter.OnEntryActionListener() {
            @Override public void onDelete(Entry entry, int position) {
                entryList.remove(position);
                entryAdapter.notifyItemRemoved(position);
            }
            @Override public void onEdit(Entry entry, int position) {
                // Simple goal page: reuse the top inputs as edit fields
                editTextGoalDate.setText(entry.getDate());
                String w = entry.getWeight();
                if (w.endsWith(" lbs")) w = w.substring(0, w.length()-4);
                editTextGoalWeight.setText(w);
            }
        });
        recyclerViewGoalEntries.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewGoalEntries.setAdapter(entryAdapter);

        // Add Entry button
        buttonAddGoalEntry.setOnClickListener(view -> {
            String date = editTextGoalDate.getText().toString().trim();
            String weight = editTextGoalWeight.getText().toString().trim();
            if(!date.isEmpty() && !weight.isEmpty()) {
                Entry newEntry = new Entry(date, weight + " lbs");
                entryList.add(0, newEntry); // newest on top
                entryAdapter.notifyItemInserted(0);
                recyclerViewGoalEntries.scrollToPosition(0);
                editTextGoalDate.setText("");
                editTextGoalWeight.setText("");
            }
        });

        // Back button
        buttonBack.setOnClickListener(view -> {
            Intent intent = new Intent(GoalWeightActivity.this, WeightEntriesActivity.class);
            startActivity(intent);
            finish();
        });

        // Logout button
        buttonLogout.setOnClickListener(view -> {
            Intent intent = new Intent(GoalWeightActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}

