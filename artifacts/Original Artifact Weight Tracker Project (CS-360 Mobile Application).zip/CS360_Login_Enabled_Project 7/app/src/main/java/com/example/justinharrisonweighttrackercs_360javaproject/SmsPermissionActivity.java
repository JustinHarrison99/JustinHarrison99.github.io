package com.example.justinharrisonweighttrackercs_360javaproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private Button buttonAllowSms, buttonDenySms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        buttonAllowSms = findViewById(R.id.buttonAllowSms);
        buttonDenySms = findViewById(R.id.buttonDenySms);

        buttonAllowSms.setOnClickListener(v -> checkSmsPermission());

        buttonDenySms.setOnClickListener(v -> {
            Toast.makeText(this, "SMS notifications denied. App will continue to function.", Toast.LENGTH_SHORT).show();
            navigateToWeightEntries();
        });
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted
            Toast.makeText(this, "SMS permission granted. Notifications enabled.", Toast.LENGTH_SHORT).show();
            navigateToWeightEntries();
        } else {
            // Request permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    private void navigateToWeightEntries() {
        Intent intent = new Intent(SmsPermissionActivity.this, WeightEntriesActivity.class);
        startActivity(intent);
        finish(); // close current activity
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted. Notifications enabled.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. Notifications disabled.", Toast.LENGTH_SHORT).show();
            }
            navigateToWeightEntries();
        }
    }
}

