package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

/**
 * SQLiteOpenHelper that creates a persistent database shell for:
 *  - users (login already implemented elsewhere)
 *  - weight_entries (date, weight, optional note)
 *
 * Provides simple CRUD helpers for weight entries.
 */
public class WeightDbHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "weight_tracker.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD_HASH = "password_hash";

    public static final String TABLE_WEIGHT = "weight_entries";
    public static final String COL_WEIGHT_ID = "id";
    public static final String COL_WEIGHT_USER_ID = "user_id";
    public static final String COL_WEIGHT_DATE = "entry_date"; // ISO yyyy-MM-dd
    public static final String COL_WEIGHT_VALUE = "weight";    // stored as text for simplicity
    public static final String COL_WEIGHT_NOTE = "note";

    public WeightDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // User table (shell – login flow manages values)
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COL_PASSWORD_HASH + " TEXT NOT NULL)");
        // Weight entries
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_WEIGHT + " (" +
                COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_WEIGHT_USER_ID + " INTEGER NOT NULL, " +
                COL_WEIGHT_DATE + " TEXT NOT NULL, " +
                COL_WEIGHT_VALUE + " TEXT NOT NULL, " +
                COL_WEIGHT_NOTE + " TEXT, " +
                "FOREIGN KEY(" + COL_WEIGHT_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + "))");
        // Basic index to keep grid snappy
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_weight_user_date ON " + TABLE_WEIGHT +
                " (" + COL_WEIGHT_USER_ID + ", " + COL_WEIGHT_DATE + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For this project shell, drop & recreate if schema changes
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ===== CRUD for weight entries =====
    public long insertWeight(long userId, String isoDate, String weight, String note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_USER_ID, userId);
        values.put(COL_WEIGHT_DATE, isoDate);
        values.put(COL_WEIGHT_VALUE, weight);
        values.put(COL_WEIGHT_NOTE, note);
        return db.insert(TABLE_WEIGHT, null, values);
    }

    public int updateWeight(long id, String isoDate, String weight, String note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_DATE, isoDate);
        values.put(COL_WEIGHT_VALUE, weight);
        values.put(COL_WEIGHT_NOTE, note);
        return db.update(TABLE_WEIGHT, values, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
    }

    public int deleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_WEIGHT, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
    }

    public List<WeightItem> getAllWeightsForUser(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_WEIGHT, null, COL_WEIGHT_USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, COL_WEIGHT_DATE + " DESC");
        List<WeightItem> list = new ArrayList<>();
        try {
            int idIx = c.getColumnIndexOrThrow(COL_WEIGHT_ID);
            int dateIx = c.getColumnIndexOrThrow(COL_WEIGHT_DATE);
            int weightIx = c.getColumnIndexOrThrow(COL_WEIGHT_VALUE);
            int noteIx = c.getColumnIndexOrThrow(COL_WEIGHT_NOTE);
            while (c.moveToNext()) {
                WeightItem item = new WeightItem(
                        c.getLong(idIx),
                        c.getString(dateIx),
                        c.getString(weightIx),
                        c.getString(noteIx)
                );
                list.add(item);
            }
        } finally {
            c.close();
        }
        return list;
    }

    // Utility: ensure a fallback "demo" user exists and return its id.
    // This allows testing CRUD independently from login.
    public long ensureDemoUser() {
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.query(TABLE_USERS, new String[]{COL_USER_ID}, COL_USERNAME + "=?",
                new String[]{"demo"}, null, null, null);
        try {
            if (c.moveToFirst()) {
                return c.getLong(0);
            }
        } finally {
            c.close();
        }
        ContentValues v = new ContentValues();
        v.put(COL_USERNAME, "demo");
        v.put(COL_PASSWORD_HASH, "demo"); // NOT secure; for local testing only
        return db.insert(TABLE_USERS, null, v);
    }
}
