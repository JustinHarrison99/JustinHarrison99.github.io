package com.example.justinharrisonweighttrackercs_360javaproject;

import android.content.Intent;
import android.os.Bundle;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WeightEntriesActivity extends AppCompatActivity {

    private RecyclerView recyclerViewEntries;
    private EntryAdapter entryAdapter;
    private ArrayList<Entry> entryList;
    private DatabaseHelper db;
    private long userId;
    private EditText editTextDate, editTextWeight;
    private Button buttonAddEntry, buttonGoalWeight, buttonLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        recyclerViewEntries = findViewById(R.id.recyclerViewEntries);
        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonAddEntry = findViewById(R.id.buttonAddEntry);
        buttonGoalWeight = findViewById(R.id.buttonGoalWeight);
        buttonLogout = findViewById(R.id.buttonLogout); // logout button

        entryList = new ArrayList<>();
        db = new DatabaseHelper(this);
        String username = getIntent().getStringExtra("username");
        if (username == null) username = "demo";
        userId = db.getUserId(username);
        if (userId == -1) {
            // Fallback: if user not found (shouldn't happen after login), create demo
            // NOTE: registration flow should already add users; keeping conservative fallback
            userId = 1; // minimal placeholder to avoid crashes
        }

        entryList = db.getWeightEntriesForUser(userId);
        entryAdapter = new EntryAdapter(entryList, new EntryAdapter.OnEntryActionListener() {
            @Override
            public void onDelete(Entry entry, int position) {
                db.deleteWeightEntry(entry.getId());
                reload();
            }
            @Override
            public void onEdit(Entry entry, int position) {
                showEditDialog(entry);
            }
        });
        recyclerViewEntries.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerViewEntries.setAdapter(entryAdapter);
        reload();

        // Add Entry button
        buttonAddEntry.setOnClickListener(view -> {
            String date = editTextDate.getText().toString().trim();
            String weight = editTextWeight.getText().toString().trim();
            if(!date.isEmpty() && !weight.isEmpty()) {
                long id = db.insertWeightEntry(userId, date, weight);
                if (id != -1) {
                    reload();
                    editTextDate.setText("");
                    editTextWeight.setText("");
                } else {
                    Toast.makeText(WeightEntriesActivity.this, "Failed to save entry", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(WeightEntriesActivity.this, "Please enter date and weight", Toast.LENGTH_SHORT).show();
            }
});

        // Goal Weight button
        buttonGoalWeight.setOnClickListener(view -> {
            Intent intent = new Intent(WeightEntriesActivity.this, GoalWeightActivity.class);
            startActivity(intent);
        });

        // Logout button
        buttonLogout.setOnClickListener(view -> {
            Intent intent = new Intent(WeightEntriesActivity.this, MainActivity.class);
            // Clear activity stack so user cannot go back
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        ArrayList<Entry> data = db.getWeightEntriesForUser(userId);
        entryAdapter.updateData(data);
    }

    private void showEditDialog(final Entry entry) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_weight, null, false);
        EditText inputDate = view.findViewById(R.id.inputDate);
        EditText inputWeight = view.findViewById(R.id.inputWeight);
        EditText inputNote = view.findViewById(R.id.inputNote);
        inputNote.setVisibility(View.GONE); // not used in simple Entry model

        inputDate.setText(entry.getDate());
        // strip " lbs" if present
        String wVal = entry.getWeight();
        if (wVal.endsWith(" lbs")) {
            wVal = wVal.substring(0, wVal.length()-4);
        }
        inputWeight.setText(wVal);

        new AlertDialog.Builder(this)
                .setTitle("Edit Entry")
                .setView(view)
                .setPositiveButton("Update", (d, which) -> {
                    String date = inputDate.getText().toString().trim();
                    String weight = inputWeight.getText().toString().trim();
                    if (date.isEmpty() || weight.isEmpty()) {
                        Toast.makeText(this, "Date and weight are required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    db.updateWeightEntry(entry.getId(), date, weight);
                    reload();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
