package com.example.justinharrisonweighttrackercs_360javaproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class WeightGridActivity extends AppCompatActivity implements WeightGridAdapter.Listener {

    private WeightDbHelper db;
    private long userId;
    private WeightGridAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_grid);

        db = new WeightDbHelper(this);
        // In a full app, get current userId from login/session.
        // For testing, ensure a demo user exists:
        userId = db.ensureDemoUser();

        RecyclerView rv = findViewById(R.id.recycler);
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new WeightGridAdapter(this);
        rv.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> showAddEditDialog(null));

        refresh();
    }

    private void refresh() {
        List<WeightItem> items = db.getAllWeightsForUser(userId);
        adapter.submitList(items);
    }

    private void showAddEditDialog(@Nullable WeightItem current) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_weight, null, false);
        EditText inputDate = view.findViewById(R.id.inputDate);
        EditText inputWeight = view.findViewById(R.id.inputWeight);
        EditText inputNote = view.findViewById(R.id.inputNote);

        if (current != null) {
            inputDate.setText(current.date);
            inputWeight.setText(current.weight);
            inputNote.setText(current.note);
        }

        new AlertDialog.Builder(this)
                .setTitle(current == null ? "Add Entry" : "Edit Entry")
                .setView(view)
                .setPositiveButton(current == null ? "Add" : "Update", (d, w) -> {
                    String date = inputDate.getText().toString().trim();
                    String weight = inputWeight.getText().toString().trim();
                    String note = inputNote.getText().toString().trim();
                    if (TextUtils.isEmpty(date) || TextUtils.isEmpty(weight)) {
                        Toast.makeText(this, "Date and weight are required.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (current == null) {
                        db.insertWeight(userId, date, weight, note);
                    } else {
                        db.updateWeight(current.id, date, weight, note);
                    }
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onEdit(WeightItem item) {
        showAddEditDialog(item);
    }

    @Override
    public void onDelete(WeightItem item) {
        new AlertDialog.Builder(this)
                .setMessage("Delete this entry?")
                .setPositiveButton("Delete", (d, w) -> {
                    db.deleteWeight(item.id);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
